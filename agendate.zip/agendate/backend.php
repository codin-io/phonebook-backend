<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "AgendaTelefonica";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Inserção de Contato
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["inserirContato"])) {
    $nome = $_POST["nome"];
    $sobrenome = $_POST["sobrenome"];
    $telefone = $_POST["telefone"];
    $email = $_POST["email"];
    $categoriaID = $_POST["categoriaID"];

    // Manipulação do upload da imagem (lembre-se de validar e processar adequadamente em uma aplicação real)
    $foto = $_FILES["foto"]["tmp_name"];
    $fotoDados = base64_encode(file_get_contents($foto));

    $sql = "INSERT INTO Contatos (Nome, Sobrenome, Telefone, Email, CategoriaID, Foto) 
            VALUES ('$nome', '$sobrenome', '$telefone', '$email', $categoriaID, '$fotoDados')";

    if ($conn->query($sql) === TRUE) {
        echo "Contato inserido com sucesso!";
    } else {
        echo "Erro na inserção do contato: " . $conn->error;
    }
}

// Seleção de Contatos
$sql = "SELECT * FROM Contatos";
$result = $conn->query($sql);
// Seleção de Contatos
$sql = "SELECT * FROM Contatos";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div style="display: flex; align-items: center; margin-bottom: 10px;">';
        echo '<div style="width: 50px; height: 50px; border-radius: 50%; overflow: hidden; margin-right: 10px;">';

        // Exibir a imagem diretamente na página
        if (isset($row['CaminhoFoto']) && !empty($row['CaminhoFoto'])) {
            echo '<img src="' . $row['CaminhoFoto'] . '" alt="Imagem do Contato" style="width: 100%; height: 100%; object-fit: cover;">';
        }
        
        echo '</div>';
        
        // Exibir os detalhes do contato
        echo '<div>';
        echo "ID: " . $row["ContatoID"] . " - Nome: " . $row["Nome"] . " - Telefone: " . $row["Telefone"];
        
        echo '</div>';

        echo '</div>';
    }
} else {
    echo "Nenhum contato encontrado.";
}



// Atualização de Contato
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["atualizarContato"])) {
    $contatoID = $_POST["contatoID"];
    $novoTelefone = $_POST["novoTelefone"];

    $sql = "UPDATE Contatos SET Telefone='$novoTelefone' WHERE ContatoID=$contatoID";

    if ($conn->query($sql) === TRUE) {
        echo "Contato atualizado com sucesso!";
    } else {
        echo "Erro na atualização do contato: " . $conn->error;
    }
}

// Exclusão de Contato
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["excluirContato"])) {
    $contatoID = $_POST["contatoID"];

    $sql = "DELETE FROM Contatos WHERE ContatoID=$contatoID";

    if ($conn->query($sql) === TRUE) {
        echo "Contato excluído com sucesso!";
    } else {
        echo "Erro na exclusão do contato: " . $conn->error;
    }
}

$conn->close();
?>
