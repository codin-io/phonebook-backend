const express = require('express');
const mysql = require('mysql2/promise');

const app = express();
const port = 3000;

// Configuração do banco de dados
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'AgendaTelefonica'
};

// Rota para a raiz
app.get('/', (req, res) => {
  res.send('Bem-vindo à sua API de Agenda Telefônica!');
});

// Rota para obter todos os contatos
app.get('/contatos', async (req, res) => {
  try {
    const connection = await mysql.createConnection(dbConfig);
    const [rows] = await connection.execute('SELECT * FROM Contatos');
    connection.end();
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro interno do servidor');
  }
});

// Rota para obter todas as categorias
app.get('/categorias', async (req, res) => {
  try {
    const connection = await mysql.createConnection(dbConfig);
    const [rows] = await connection.execute('SELECT * FROM Categorias');
    connection.end();
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro interno do servidor');
  }
});



// Rota para obter todos os usuários
app.get('/usuarios', async (req, res) => {
  try {
    const connection = await mysql.createConnection(dbConfig);
    const [rows] = await connection.execute('SELECT * FROM Usuarios');
    connection.end();
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro interno do servidor');
  }
});



// Inicie o servidor
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
